"""
Phonetic Mapping using Hugging Face Wav2Vec2 for Forced Alignment
Maps detected segments to actual phones (e.g., [p] vs [b]) and computes RMSE
"""

import numpy as np
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor, Wav2Vec2CTCTokenizer
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import json
import os
import sys
import re
from collections import defaultdict

DEFAULT_PROJECT_PATH = "/content/drive/MyDrive/q1_cepstral_pipeline"

# IPA phone mapping for CTC tokens (simplified)
CTC_TO_PHONE = {
    ' ': '<sil>', '<pad>': '<sil>', '<unk>': '<unk>',
    'a': 'ɑ', 'e': 'ɛ', 'i': 'ɪ', 'o': 'ɔ', 'u': 'ʊ',
    'aa': 'ɑ', 'ae': 'ɛ', 'ah': 'ʌ', 'ao': 'ɔ', 'aw': 'aʊ',
    'ay': 'aɪ', 'b': 'b', 'ch': 'tʃ', 'd': 'd', 'dh': 'ð',
    'eh': 'ɛ', 'er': 'ɝ', 'ey': 'eɪ', 'f': 'f', 'g': 'ɡ',
    'hh': 'h', 'ih': 'ɪ', 'iy': 'i', 'jh': 'dʒ', 'k': 'k',
    'l': 'l', 'm': 'm', 'n': 'n', 'ng': 'ŋ', 'ow': 'oʊ',
    'oy': 'ɔɪ', 'p': 'p', 'r': 'ɹ', 's': 's', 'sh': 'ʃ',
    't': 't', 'th': 'θ', 'uh': 'ʊ', 'uw': 'u', 'v': 'v',
    'w': 'w', 'y': 'j', 'z': 'z', 'zh': 'ʒ',
}

def load_audio_for_alignment(filepath, target_sr=16000, max_duration=30):
    """Load and prepare audio for Wav2Vec2 alignment"""
    try:
        import torchaudio
        waveform, sr = torchaudio.load(filepath)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        if sr != target_sr:
            waveform = torchaudio.functional.resample(waveform, sr, target_sr)
            sr = target_sr
        audio = waveform.numpy().flatten()
        audio = audio / (np.max(np.abs(audio)) + 1e-8)
        
        # Trim long files
        max_samples = int(max_duration * sr)
        if len(audio) > max_samples:
            print(f"⚠️  Trimming audio from {len(audio)/sr:.1f}s to {max_duration}s")
            audio = audio[:max_samples]
        
        return audio, sr
    except Exception as e:
        print(f"❌ Error loading {filepath}: {e}")
        return None, None


class PhoneticAligner:
    """Wav2Vec2-based phonetic alignment with phone-level mapping"""
    
    def __init__(self, model_name="facebook/wav2vec2-base-960h", device=None):
        if device is None:
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
        print(f"🔄 Loading {model_name} on {device}...")
        self.device = device
        self.processor = Wav2Vec2Processor.from_pretrained(model_name)
        self.model = Wav2Vec2ForCTC.from_pretrained(model_name).to(device)
        self.tokenizer = Wav2Vec2CTCTokenizer.from_pretrained(model_name)
        self.model.eval()
        self.frame_rate = 50  # Wav2Vec2 outputs ~50 frames/sec
        print(f"✅ Model loaded on {device} (frame_rate={self.frame_rate}fps)")
        
    def _decode_tokens(self, token_ids):
        """Convert token IDs to phone sequence with timing"""
        phones = []
        for token_id in token_ids:
            token = self.tokenizer.decode([token_id]).strip().lower()
            if token and token not in ['<pad>', '<s>', '</s>', '<unk>']:
                # Map CTC token to IPA phone
                phone = CTC_TO_PHONE.get(token, token)
                phones.append(phone)
        return phones
    
    def align_audio(self, audio, sample_rate=16000):
        """
        Get phone-level alignment with timestamps
        
        Returns:
            phone_alignments: list of {phone, start_time, end_time, confidence}
            transcription: decoded text
        """
        # Ensure 16kHz
        if sample_rate != 16000:
            import torchaudio
            audio_tensor = torch.tensor(audio).unsqueeze(0)
            audio_tensor = torchaudio.functional.resample(audio_tensor, sample_rate, 16000)
            audio = audio_tensor.numpy().flatten()
            sample_rate = 16000
        
        # Preprocess
        input_values = self.processor(audio, sampling_rate=sample_rate, 
                                     return_tensors="pt").input_values.to(self.device)
        
        # Forward pass
        with torch.no_grad():
            logits = self.model(input_values).logits
            probabilities = torch.softmax(logits, dim=-1)
        
        # Greedy decoding
        predicted_ids = torch.argmax(logits, dim=-1)[0].cpu()
        transcription = self.processor.batch_decode(predicted_ids)[0]
        
        # Extract phone-level alignments with timing
        phone_alignments = []
        current_phone = None
        start_frame = 0
        
        for i, token_id in enumerate(predicted_ids):
            token = self.tokenizer.decode([token_id]).strip().lower()
            if not token or token in ['<pad>', '<s>', '</s>', '<unk>']:
                continue
            
            phone = CTC_TO_PHONE.get(token, token)
            confidence = probabilities[0, i, token_id].cpu().item()
            
            if phone != current_phone:
                # Save previous phone segment
                if current_phone is not None:
                    phone_alignments.append({
                        'phone': current_phone,
                        'start_time': start_frame / self.frame_rate,
                        'end_time': i / self.frame_rate,
                        'confidence': np.mean([p['confidence'] for p in phone_alignments 
                                              if p['phone'] == current_phone]) if phone_alignments else confidence
                    })
                # Start new phone
                current_phone = phone
                start_frame = i
        
        # Don't forget the last phone
        if current_phone is not None:
            phone_alignments.append({
                'phone': current_phone,
                'start_time': start_frame / self.frame_rate,
                'end_time': len(predicted_ids) / self.frame_rate,
                'confidence': confidence
            })
        
        return phone_alignments, transcription
    
    def extract_phone_boundaries(self, phone_alignments):
        """Extract boundary times from phone alignments"""
        boundaries = []
        for p in phone_alignments:
            # Mark phone start as boundary
            boundaries.append((p['start_time'], f"phone:{p['phone']}"))
        return boundaries
    
    def compute_boundary_rmse(self, manual_boundaries, phone_boundaries, tolerance=0.1):
        """
        Compute RMSE between manual voiced/unvoiced boundaries and phone boundaries
        
        Args:
            manual_boundaries: list of (time, label) from voiced_unvoiced.py
            phone_boundaries: list of (time, phone_label) from Wav2Vec2
            tolerance: seconds within which to consider a match
        
        Returns:
            dict with RMSE and detailed matching stats
        """
        if len(phone_boundaries) == 0:
            return {
                'rmse_seconds': float('inf'),
                'rmse_ms': float('inf'),
                'matched_count': 0,
                'error': 'No phone boundaries detected'
            }
        
        # Extract just times for matching
        manual_times = [t for t, _ in manual_boundaries]
        phone_times = [t for t, _ in phone_boundaries]
        
        # Match each manual boundary to nearest phone boundary
        matched = []
        unmatched_manual = []
        used_phone_idx = set()
        
        for man_time, man_label in manual_boundaries:
            # Find closest unused phone boundary
            best_error = float('inf')
            best_idx = None
            
            for idx, phone_time in enumerate(phone_times):
                if idx in used_phone_idx:
                    continue
                error = abs(man_time - phone_time)
                if error < best_error:
                    best_error = error
                    best_idx = idx
            
            if best_idx is not None and best_error <= tolerance:
                matched.append({
                    'manual_time': man_time,
                    'manual_label': man_label,
                    'phone_time': phone_times[best_idx],
                    'phone_label': phone_boundaries[best_idx][1],
                    'error': best_error
                })
                used_phone_idx.add(best_idx)
            else:
                unmatched_manual.append((man_time, man_label))
        
        # Calculate RMSE
        if len(matched) > 0:
            errors = [m['error'] for m in matched]
            rmse = np.sqrt(np.mean(np.array(errors)**2))
        else:
            rmse = float('inf')
        
        return {
            'rmse_seconds': rmse,
            'rmse_ms': rmse * 1000 if rmse != float('inf') else float('inf'),
            'matched_count': len(matched),
            'total_manual': len(manual_boundaries),
            'total_phone': len(phone_boundaries),
            'unmatched_manual': len(unmatched_manual),
            'tolerance_seconds': tolerance,
            'matched_details': matched
        }
    
    def plot_phone_alignment(self, audio, sample_rate, manual_boundaries, phone_alignments, 
                            output_path, title="Phone-Level Alignment"):
        """Visualize phone-level alignment with manual boundaries"""
        fig, axes = plt.subplots(4, 1, figsize=(16, 12), sharex=True)
        t = np.arange(len(audio)) / sample_rate
        
        # 1. Original waveform
        axes[0].plot(t, audio, linewidth=0.5, color='gray')
        axes[0].set_title('Original Audio Waveform')
        axes[0].set_ylabel('Amplitude')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_xlim(0, min(10.0, t[-1]))
        
        # 2. Manual voiced/unvoiced boundaries
        axes[1].plot(t, audio, linewidth=0.3, alpha=0.2)
        for time, label in manual_boundaries:
            if time < 10.0:
                color = 'blue' if label == 'voiced' else 'red'
                axes[1].axvline(x=time, color=color, linestyle='--', linewidth=2, 
                              label=label if time == manual_boundaries[0][0] else "")
        axes[1].set_title('Manual Boundaries: Voiced (blue) / Unvoiced (red)')
        axes[1].set_ylabel('Amplitude')
        axes[1].legend(fontsize=8)
        axes[1].grid(True, alpha=0.3)
        axes[1].set_xlim(0, min(10.0, t[-1]))
        
        # 3. Phone-level alignment (colored bars)
        axes[2].plot(t, audio, linewidth=0.1, alpha=0.1)
        colors = plt.cm.tab20(np.linspace(0, 1, 20))
        phone_color_map = {p: colors[i % len(colors)] for i, p in enumerate(set(p['phone'] for p in phone_alignments))}
        
        for p in phone_alignments:
            if p['start_time'] < 10.0:
                axes[2].axvspan(p['start_time'], p['end_time'], 
                               color=phone_color_map.get(p['phone'], 'gray'), 
                               alpha=0.3, label=p['phone'] if p == phone_alignments[0] else "")
                # Phone label
                mid_time = (p['start_time'] + p['end_time']) / 2
                if mid_time < 10.0:
                    axes[2].text(mid_time, 0.3, p['phone'], fontsize=7, 
                                rotation=90, ha='center', va='bottom', alpha=0.8)
        
        axes[2].set_title('Wav2Vec2 Phone-Level Alignment')
        axes[2].set_ylabel('Amplitude')
        axes[2].grid(True, alpha=0.3)
        axes[2].set_xlim(0, min(10.0, t[-1]))
        
        # 4. Boundary comparison (matched vs unmatched)
        axes[3].plot(t, audio, linewidth=0.1, alpha=0.1)
        
        # Plot matched boundaries (green)
        for m in [d for d in phone_alignments if any(d['phone'] in str(b) for b in manual_boundaries)][:10]:
            if m['start_time'] < 10.0:
                axes[3].axvline(x=m['start_time'], color='green', linestyle='-', linewidth=2, alpha=0.7)
        
        # Plot manual boundaries (blue/red)
        for time, label in manual_boundaries:
            if time < 10.0:
                color = 'blue' if label == 'voiced' else 'red'
                axes[3].axvline(x=time, color=color, linestyle='--', linewidth=1.5)
        
        axes[3].set_title('Boundary Comparison: Manual (dashed) vs Phone (solid green=matched)')
        axes[3].set_xlabel('Time (seconds)')
        axes[3].set_ylabel('Amplitude')
        axes[3].grid(True, alpha=0.3)
        axes[3].set_xlim(0, min(10.0, t[-1]))
        
        plt.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        print(f" Alignment plot saved: {output_path}")
        return output_path
    
    def generate_phone_report(self, phone_alignments, manual_boundaries, rmse_results, output_path):
        """Generate detailed phone-level report"""
        report = []
        report.append("# Phone-Level Alignment Report\n")
        report.append(f"**Audio Duration**: {phone_alignments[-1]['end_time']:.2f}s\n")
        report.append(f"**Total Phones Detected**: {len(phone_alignments)}\n")
        report.append(f"**Manual Boundaries**: {len(manual_boundaries)}\n\n")
        
        # Phone sequence
        report.append("## Detected Phone Sequence\n")
        report.append("| Time (s) | Phone | Duration (ms) | Confidence |\n")
        report.append("|----------|-------|---------------|------------|\n")
        for p in phone_alignments[:20]:  # First 20 phones
            duration = (p['end_time'] - p['start_time']) * 1000
            report.append(f"| {p['start_time']:.3f} | `{p['phone']}` | {duration:.1f} | {p['confidence']:.3f} |\n")
        if len(phone_alignments) > 20:
            report.append(f"\n*... and {len(phone_alignments) - 20} more phones*\n")
        
        # RMSE results
        report.append("\n## Boundary Alignment Results\n")
        if rmse_results['rmse_ms'] != float('inf'):
            report.append(f"- **RMSE**: {rmse_results['rmse_ms']:.2f} ms\n")
            report.append(f"- **Matched Boundaries**: {rmse_results['matched_count']}/{rmse_results['total_manual']}\n")
            report.append(f"- **Tolerance**: {rmse_results['tolerance_seconds']*1000:.0f} ms\n")
        else:
            report.append("- **RMSE**: Could not compute (no matches)\n")
        
        # Matched pairs detail
        if rmse_results['matched_details']:
            report.append("\n### Matched Boundary Pairs\n")
            report.append("| Manual Time | Manual Label | Phone Time | Phone | Error (ms) |\n")
            report.append("|-------------|--------------|------------|-------|------------|\n")
            for m in rmse_results['matched_details'][:10]:
                report.append(f"| {m['manual_time']:.3f}s | {m['manual_label']} | {m['phone_time']:.3f}s | {m['phone_label']} | {m['error']*1000:.1f} |\n")
        
        # Save report
        with open(output_path, 'w') as f:
            f.write(''.join(report))
        
        print(f" Phone report saved: {output_path}")
        return output_path


def run_full_pipeline(audio_path, project_path=None):
    """
    Run complete phonetic mapping pipeline with phone-level alignment
    
    Returns:
        results dict with RMSE and alignment details
    """
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    os.makedirs(f"{project_path}/outputs", exist_ok=True)
    
    print(f" Running Phonetic Mapping: {os.path.basename(audio_path)}")
    
    # Load audio
    audio, sample_rate = load_audio_for_alignment(audio_path, target_sr=16000, max_duration=30)
    if audio is None:
        return None
    
    print(f" Loaded: {len(audio)/sample_rate:.2f}s @ {sample_rate} Hz")
    
    # Detect manual boundaries first
    print(" Detecting manual voiced/unvoiced boundaries...")
    from voiced_unvoiced import VoicedUnvoicedDetector
    detector = VoicedUnvoicedDetector(sample_rate=sample_rate)
    manual_boundaries, labels, scores, times = detector.detect_boundaries(audio)
    print(f" Detected {len(manual_boundaries)} manual boundaries")
    
    # Initialize aligner and run alignment
    print(" Loading Wav2Vec2 model...")
    aligner = PhoneticAligner()
    
    print(" Running phone-level alignment...")
    phone_alignments, transcription = aligner.align_audio(audio, sample_rate)
    print(f" Detected {len(phone_alignments)} phones: {' '.join(p['phone'] for p in phone_alignments[:15])}...")
    
    # Extract phone boundaries for RMSE calculation
    phone_boundaries = aligner.extract_phone_boundaries(phone_alignments)
    
    # Compute RMSE
    print(" Computing boundary RMSE...")
    rmse_results = aligner.compute_boundary_rmse(manual_boundaries, phone_boundaries, tolerance=0.1)
    
    # Generate outputs
    plot_path = f"{project_path}/outputs/alignment_results.pdf"
    aligner.plot_phone_alignment(audio, sample_rate, manual_boundaries, phone_alignments, 
                                 plot_path, title=f"Phone Alignment: {os.path.basename(audio_path)}")
    
    report_path = f"{project_path}/outputs/phone_report.md"
    aligner.generate_phone_report(phone_alignments, manual_boundaries, rmse_results, report_path)
    
    # Save JSON results
    json_path = f"{project_path}/outputs/alignment_results.json"
    with open(json_path, 'w') as f:
        json.dump({
            'transcription': transcription,
            'phone_count': len(phone_alignments),
            'manual_boundary_count': len(manual_boundaries),
            'rmse_results': rmse_results,
            'first_10_phones': phone_alignments[:10]
        }, f, indent=2)
    
    # Print summary
    print("\n" + "="*70)
    print(" PHONETIC MAPPING RESULTS")
    print("="*70)
    print(f"Transcription: \"{transcription}\"")
    print(f"Phones detected: {len(phone_alignments)}")
    print(f"Manual boundaries: {len(manual_boundaries)}")
    if rmse_results['rmse_ms'] != float('inf'):
        print(f" RMSE: {rmse_results['rmse_ms']:.2f} ms")
        print(f" Matched: {rmse_results['matched_count']}/{rmse_results['total_manual']} boundaries")
    else:
        print(f"  RMSE: Could not compute (tolerance={rmse_results['tolerance_seconds']*1000:.0f}ms)")
    print(f" Plot: {plot_path}")
    print(f" Report: {report_path}")
    print("="*70)
    
    return {
        'transcription': transcription,
        'phones': phone_alignments,
        'manual_boundaries': manual_boundaries,
        'rmse_results': rmse_results,
        'outputs': {
            'plot': plot_path,
            'report': report_path,
            'json': json_path
        }
    }


def run_demo_synthetic(project_path=None):
    """Demo with synthetic signal (no model download)"""
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    print(" Phonetic Mapping Demo (Synthetic - No Model)")
    print("\n Expected workflow with real audio:")
    print("  1. Load audio → Resample to 16kHz")
    print("  2. Detect voiced/unvoiced boundaries (cepstral method)")
    print("  3. Run Wav2Vec2 for phone-level alignment")
    print("  4. Map CTC tokens to IPA phones ([p], [b], [t], etc.)")
    print("  5. Compute RMSE between manual and phone boundaries")
    print("  6. Generate visualization + report")
    print("\n For real results: run with --input your_file.m4a")
    
    return {'demo': True}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Phonetic Mapping with Wav2Vec2')
    parser.add_argument('--input', '-i', type=str, default=None, help='Path to real audio file')
    parser.add_argument('--project-path', '-p', type=str, default=DEFAULT_PROJECT_PATH)
    parser.add_argument('--synthetic', '-s', action='store_true', help='Use synthetic demo')
    
    #  FIX: Use parse_known_args() to ignore Jupyter's hidden arguments
    args, unknown = parser.parse_known_args()
    
    # Optional: Print unknown args for debugging
    # if unknown:
    #     print(f"  Ignoring unknown arguments: {unknown}")
    
    if args.synthetic or (not args.input):
        run_demo_synthetic(args.project_path)
    elif args.input and os.path.exists(args.input):
        results = run_full_pipeline(args.input, args.project_path)
        if results and results['rmse_results']['rmse_ms'] != float('inf'):
            print(f"\n Final RMSE for submission: {results['rmse_results']['rmse_ms']:.2f} ms")
    else:
        print(f" File not found: {args.input}")
        print(" Usage: python phonetic_mapping.py --input /path/to/audio.m4a")
