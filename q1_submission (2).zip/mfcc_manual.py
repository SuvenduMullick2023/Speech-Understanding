"""
Manual MFCC/Cepstrum Feature Extraction Engine
Supports: Synthetic signals AND real audio files (.wav, .m4a, .flac, .mp3)
"""

import numpy as np
from scipy.fftpack import dct, fft
from scipy.signal import get_window
import matplotlib.pyplot as plt
import os
import sys

# Default project path
DEFAULT_PROJECT_PATH = "/content/drive/MyDrive/q1_cepstral_pipeline"

def load_audio_file(filepath, target_sr=16000):
   """
   Load audio file with automatic resampling
   
   Args:
       filepath: Path to audio file (.wav, .m4a, .flac, .mp3)
       target_sr: Target sample rate (default: 16000)
   
   Returns:
       signal: Mono audio as numpy array
       sample_rate: Actual sample rate after resampling
   """
   try:
       import torchaudio
       
       # Load with torchaudio (supports M4A via ffmpeg)
       waveform, sr = torchaudio.load(filepath)
       
       # Convert to mono if stereo
       if waveform.shape[0] > 1:
           waveform = waveform.mean(dim=0, keepdim=True)
       
       # Resample if needed
       if sr != target_sr:
           waveform = torchaudio.functional.resample(waveform, sr, target_sr)
           sr = target_sr
       
       # Convert to numpy and normalize
       signal = waveform.numpy().flatten()
       signal = signal / (np.max(np.abs(signal)) + 1e-8)  # Normalize to [-1, 1]
       
       return signal, sr
       
   except ImportError:
       # Fallback to librosa
       import librosa
       signal, sr = librosa.load(filepath, sr=target_sr, mono=True)
       signal = signal / (np.max(np.abs(signal)) + 1e-8)
       return signal, sr
       
   except Exception as e:
       print(f" Error loading {filepath}: {e}")
       return None, None


class ManualMFCC:
   """Handcrafted MFCC extraction from first principles"""
   
   def __init__(self, sample_rate=16000, n_mfcc=13, n_fft=512, 
                hop_length=160, win_length=400, n_mels=26):
       self.sample_rate = sample_rate
       self.n_mfcc = n_mfcc
       self.n_fft = n_fft
       self.hop_length = hop_length
       self.win_length = win_length
       self.n_mels = n_mels
       self.preemphasis = 0.97
       self.mel_filters = self._create_mel_filterbank()
       
   def _pre_emphasis(self, signal):
       """Apply pre-emphasis filter: y[t] = x[t] - α·x[t-1]"""
       return np.append(signal[0], signal[1:] - self.preemphasis * signal[:-1])
   
   def _frame_signal(self, signal):
       """Frame signal with overlap"""
       num_frames = 1 + int(np.ceil((len(signal) - self.win_length) / self.hop_length))
       frames = np.zeros((num_frames, self.win_length))
       for i in range(num_frames):
           start = i * self.hop_length
           end = min(start + self.win_length, len(signal))
           frames[i, :end-start] = signal[start:end]
       return frames
   
   def _create_mel_filterbank(self):
       """Create triangular Mel-scale filterbank"""
       freqs = np.fft.rfftfreq(self.n_fft, 1/self.sample_rate)
       def hz_to_mel(hz): return 2595 * np.log10(1 + hz/700)
       def mel_to_hz(mel): return 700 * (10**(mel/2595) - 1)
       mel_min = hz_to_mel(0)
       mel_max = hz_to_mel(self.sample_rate/2)
       mel_points = np.linspace(mel_min, mel_max, self.n_mels + 2)
       hz_points = mel_to_hz(mel_points)
       filters = np.zeros((self.n_mels, len(freqs)))
       for m in range(1, self.n_mels + 1):
           f_lower = hz_points[m-1]
           f_center = hz_points[m]
           f_upper = hz_points[m+1]
           for i, f in enumerate(freqs):
               if f_lower <= f < f_center:
                   filters[m-1, i] = (f - f_lower) / (f_center - f_lower)
               elif f_center <= f < f_upper:
                   filters[m-1, i] = (f_upper - f) / (f_upper - f_center)
       return filters
   
   def extract_mfcc(self, signal, window_type='hamming'):
       """Extract MFCC features manually"""
       signal = self._pre_emphasis(signal.astype(np.float64))
       frames = self._frame_signal(signal)
       window = get_window(window_type, self.win_length)
       frames = frames * window
       fft_frames = np.abs(fft(frames, n=self.n_fft))[:, :self.n_fft//2 + 1]
       power_spectrum = fft_frames ** 2
       mel_spectrum = np.dot(power_spectrum, self.mel_filters.T)
       mel_spectrum = np.where(mel_spectrum == 0, np.finfo(float).eps, mel_spectrum)
       log_mel = np.log(mel_spectrum)
       mfcc = dct(log_mel, type=2, axis=1, norm='ortho')[:, :self.n_mfcc]
       return mfcc
   
   def extract_cepstrum(self, signal, window_type='hamming'):
       """Extract cepstrum for quefrency analysis"""
       signal = self._pre_emphasis(signal.astype(np.float64))
       frames = self._frame_signal(signal)
       window = get_window(window_type, self.win_length)
       frames = frames * window
       cepstra = []
       for frame in frames:
           spectrum = np.abs(fft(frame, n=self.n_fft))[:self.n_fft//2 + 1]
           spectrum = np.where(spectrum == 0, np.finfo(float).eps, spectrum)
           log_spectrum = np.log(spectrum)
           cepstrum = np.real(fft(log_spectrum))
           cepstra.append(cepstrum)
       cepstra = np.array(cepstra)
       quefrency_split = int(0.004 * self.sample_rate)
       low_quefrency = cepstra[:, :quefrency_split]
       high_quefrency = cepstra[:, quefrency_split:quefrency_split*3]
       return low_quefrency, high_quefrency, cepstra


def plot_mfcc_comparison(signal, sample_rate=16000, project_path=None, title="MFCC Analysis"):
   """Visualize MFCC extraction stages"""
   if project_path is None:
       project_path = DEFAULT_PROJECT_PATH
   
   mfcc_engine = ManualMFCC(sample_rate=sample_rate)
   mfcc = mfcc_engine.extract_mfcc(signal)
   low_q, high_q, cepstra = mfcc_engine.extract_cepstrum(signal)
   
   fig, axes = plt.subplots(3, 2, figsize=(14, 10))
   
   # Original signal (first 2000 samples)
   axes[0, 0].plot(signal[:2000])
   axes[0, 0].set_title('Original Signal (first 2000 samples)')
   axes[0, 0].set_xlabel('Samples')
   axes[0, 0].set_ylabel('Amplitude')
   axes[0, 0].grid(True, alpha=0.3)
   
   # Spectrogram
   from scipy.signal import spectrogram
   f, t_spec, Sxx = spectrogram(signal, fs=sample_rate, nperseg=256)
   axes[0, 1].pcolormesh(t_spec, f, 10*np.log10(Sxx + 1e-10), shading='gouraud')
   axes[0, 1].set_title('Spectrogram')
   axes[0, 1].set_xlabel('Time (s)')
   axes[0, 1].set_ylabel('Frequency (Hz)')
   
   # MFCC heatmap
   axes[1, 0].imshow(mfcc.T, aspect='auto', origin='lower', cmap='viridis')
   axes[1, 0].set_title(f'MFCC Coefficients ({mfcc.shape[1]} × {mfcc.shape[0]})')
   axes[1, 0].set_xlabel('Frame')
   axes[1, 0].set_ylabel('Coefficient')
   
   # Cepstrum
   axes[1, 1].plot(np.mean(cepstra, axis=0)[:200])
   axes[1, 1].axvline(x=64, color='red', linestyle='--', label='4ms split')
   axes[1, 1].set_title('Mean Cepstrum (Quefrency Domain)')
   axes[1, 1].set_xlabel('Quefrency (samples)')
   axes[1, 1].set_ylabel('Magnitude')
   axes[1, 1].legend()
   axes[1, 1].grid(True, alpha=0.3)
   
   # Low vs High Quefrency
   axes[2, 0].plot(np.mean(low_q, axis=0), label='Low Quefrency (<4ms)', color='blue')
   axes[2, 0].set_title('Low Quefrency: Vocal Tract Envelope')
   axes[2, 0].set_xlabel('Quefrency')
   axes[2, 0].set_ylabel('Magnitude')
   axes[2, 0].legend()
   axes[2, 0].grid(True, alpha=0.3)
   
   axes[2, 1].plot(np.mean(high_q, axis=0), label='High Quefrency (>4ms)', color='red')
   axes[2, 1].set_title('High Quefrency: Pitch Periodicity')
   axes[2, 1].set_xlabel('Quefrency')
   axes[2, 1].set_ylabel('Magnitude')
   axes[2, 1].legend()
   axes[2, 1].grid(True, alpha=0.3)
   
   plt.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
   plt.tight_layout()
   
   output_path = f"{project_path}/outputs/mfcc_plots.pdf"
   plt.savefig(output_path, dpi=300, bbox_inches='tight')
   plt.close()
   
   print(f" MFCC plots saved to {output_path}")
   return mfcc, cepstra


def run_demo_synthetic(project_path=None):
   """Run demo with synthetic signal"""
   if project_path is None:
       project_path = DEFAULT_PROJECT_PATH
   
   print("🔧 Testing Manual MFCC Engine with Synthetic Signal...")
   
   sample_rate = 16000
   duration = 2.0
   t = np.linspace(0, duration, int(sample_rate * duration))
   
   # Voiced: harmonic signal
   voiced = 0.5 * np.sin(2*np.pi*150*t) + 0.3*np.sin(2*np.pi*300*t)
   # Unvoiced: noise-like
   unvoiced = 0.2 * np.random.randn(len(t))
   
   # Combine
   signal = np.zeros_like(t)
   signal[:len(t)//2] = voiced[:len(t)//2]
   signal[len(t)//2:] = unvoiced[len(t)//2]
   
   mfcc, cepstra = plot_mfcc_comparison(signal, sample_rate, project_path, 
                                        title="Synthetic Signal: Voiced + Unvoiced")
 
   print(f" MFCC shape: {mfcc.shape}")
   print(f" Cepstrum shape: {cepstra.shape}")
   print(" Manual MFCC engine working!")
   
   return mfcc, cepstra


def run_demo_real(filepath, project_path=None):
   """Run analysis on real audio file"""
   if project_path is None:
       project_path = DEFAULT_PROJECT_PATH
   
   print(f" Loading real audio: {filepath}")
   
   # Load audio
   signal, sample_rate = load_audio_file(filepath, target_sr=16000)
   
   if signal is None:
       print(f" Failed to load {filepath}")
       return None, None
   
   print(f" Loaded: {len(signal)/sample_rate:.2f} seconds @ {sample_rate} Hz")
   
   # Extract and plot
   filename = os.path.basename(filepath)
   title = f"Real Speech: {filename}"
   
   mfcc, cepstra = plot_mfcc_comparison(signal, sample_rate, project_path, title=title)
   
   print(f" MFCC shape: {mfcc.shape}")
   print(f" Cepstrum shape: {cepstra.shape}")
   print(f" Duration: {len(signal)/sample_rate:.2f}s")
   print(f" Frames: {mfcc.shape[0]} (10ms hop)")
   
   # Save processed signal for other modules
   output_signal = f"{project_path}/data/processed_signal.npy"
   np.save(output_signal, {'signal': signal, 'sample_rate': sample_rate})
   print(f" Processed signal saved to {output_signal}")
   
   return mfcc, cepstra


if __name__ == "__main__":
   import argparse
   
   parser = argparse.ArgumentParser(description='Manual MFCC/Cepstrum Engine')
   parser.add_argument('--input', '-i', type=str, default=None,
                      help='Path to real audio file (.wav, .m4a, .flac, .mp3)')
   parser.add_argument('--project-path', '-p', type=str, default=DEFAULT_PROJECT_PATH,
                      help='Project output directory')
   parser.add_argument('--synthetic', '-s', action='store_true',
                      help='Use synthetic demo signal (default)')
   
   args = parser.parse_args()
   project_path = args.project_path
   
   # Ensure output directory exists
   os.makedirs(f"{project_path}/outputs", exist_ok=True)
   
   if args.input and os.path.exists(args.input):
       # Process real audio file
       run_demo_real(args.input, project_path)
   else:
       # Fall back to synthetic demo
       print("  No valid input file provided, using synthetic demo")
       run_demo_synthetic(project_path)
