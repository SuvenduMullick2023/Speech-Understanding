"""
Voiced/Unvoiced Boundary Detection using Cepstrum Analysis
Uses low-quefrency (vocal tract) and high-quefrency (pitch) regions
FIXED: Consistent frame parameters across all features
"""

import numpy as np
from scipy.signal import find_peaks
from mfcc_manual import ManualMFCC
import matplotlib.pyplot as plt

class VoicedUnvoicedDetector:
    """Detect voiced/unvoiced segments using cepstral features"""

    def __init__(self, sample_rate=16000, frame_length=400, hop_length=160, quefrency_split_ms=4):
        """
        Args:
            sample_rate: Audio sample rate (Hz)
            frame_length: Frame size in samples (25ms @ 16kHz = 400)
            hop_length: Hop size in samples (10ms @ 16kHz = 160)
            quefrency_split_ms: Quefrency split point in milliseconds
        """
        self.sample_rate = sample_rate
        self.frame_length = frame_length
        self.hop_length = hop_length
        self.quefrency_split = int(quefrency_split_ms * sample_rate / 1000)
        self.mfcc_engine = ManualMFCC(
            sample_rate=sample_rate,
            win_length=frame_length,
            hop_length=hop_length
        )

    def _compute_zcr(self, signal):
        """Zero-crossing rate per frame (consistent with cepstrum frames)"""
        zcr = []
        for i in range(0, len(signal) - self.frame_length, self.hop_length):
            frame = signal[i:i+self.frame_length]
            zc = np.sum(np.abs(np.diff(np.signbit(frame)))) / (2 * len(frame))
            zcr.append(zc)
        return np.array(zcr)

    def _compute_energy(self, signal):
        """Frame energy (consistent with cepstrum frames)"""
        energy = []
        for i in range(0, len(signal) - self.frame_length, self.hop_length):
            frame = signal[i:i+self.frame_length]
            energy.append(np.sum(frame**2))
        return np.array(energy)

    def _compute_pitch_strength(self, cepstra):
        """Measure pitch periodicity from high-quefrency cepstrum"""
        # Pitch typically appears at quefrency 2-20ms
        pitch_region = cepstra[:, self.quefrency_split:min(self.quefrency_split*5, cepstra.shape[1])]

        # Energy in pitch region as pitch strength proxy
        pitch_strength = np.sum(np.abs(pitch_region), axis=1)

        return pitch_strength

    def _compute_vocal_tract_energy(self, low_quefrency):
        """Energy in low-quefrency region (vocal tract envelope)"""
        return np.sum(np.abs(low_quefrency), axis=1)

    def detect_boundaries(self, signal):
        """
        Detect voiced/unvoiced boundaries

        Returns:
            boundaries: list of (time, label) tuples
            labels: array of 'voiced'/'unvoiced' per frame
            voiced_score: confidence score per frame
            frame_times: time position of each frame
        """
        # Extract cepstral features
        low_q, high_q, cepstra = self.mfcc_engine.extract_cepstrum(signal)

        # Compute ALL features with consistent framing
        zcr = self._compute_zcr(signal)
        energy = self._compute_energy(signal)
        pitch_strength = self._compute_pitch_strength(cepstra)
        vt_energy = self._compute_vocal_tract_energy(low_q)

        # Debug: Check shapes match
        min_len = min(len(zcr), len(energy), len(pitch_strength), len(vt_energy))
        zcr = zcr[:min_len]
        energy = energy[:min_len]
        pitch_strength = pitch_strength[:min_len]
        vt_energy = vt_energy[:min_len]

        # Normalize features
        def normalize(x):
            if np.std(x) < 1e-10:
                return np.zeros_like(x)
            return (x - np.mean(x)) / (np.std(x) + 1e-10)

        zcr_norm = normalize(zcr)
        energy_norm = normalize(energy)
        pitch_norm = normalize(pitch_strength)
        vt_norm = normalize(vt_energy)

        # Decision rule: Voiced if:
        # - Low ZCR (< threshold)
        # - High energy (> threshold)
        # - Strong pitch periodicity (> threshold)
        # - Strong vocal tract envelope (> threshold)
        voiced_score = (
            -0.3 * zcr_norm +      # Lower ZCR = more voiced
            0.3 * energy_norm +    # Higher energy = more voiced
            0.25 * pitch_norm +    # Stronger pitch = more voiced
            0.15 * vt_norm         # Stronger vocal tract = more voiced
        )

        # Threshold for voiced/unvoiced
        threshold = 0.0
        labels = ['voiced' if s > threshold else 'unvoiced' for s in voiced_score]

        # Find boundaries (transitions)
        boundaries = []
        frame_times = np.arange(len(labels)) * self.hop_length / self.sample_rate

        for i in range(1, len(labels)):
            if labels[i] != labels[i-1]:
                boundaries.append((frame_times[i], labels[i]))

        return boundaries, labels, voiced_score, frame_times

    def plot_detection(self, signal, boundaries, labels, voiced_score, frame_times, sample_rate=16000,PROJECT_PATH=None):
        """Visualize voiced/unvoiced detection"""
        fig, axes = plt.subplots(4, 1, figsize=(14, 10), sharex=True)

        # Original signal
        t = np.arange(len(signal)) / sample_rate
        axes[0].plot(t, signal, linewidth=0.5)
        axes[0].set_title('Original Signal')
        axes[0].set_ylabel('Amplitude')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_xlim(0, min(3.0, t[-1]))  # Show first 3 seconds

        # Voiced score over time
        axes[1].plot(frame_times, voiced_score, linewidth=2, color='blue')
        axes[1].axhline(y=0, linestyle='--', color='red', label='Threshold')
        axes[1].set_title('Voiced Score (higher = more voiced)')
        axes[1].set_ylabel('Score')
        axes[1].legend()
        axes[1].grid(True, alpha=0.3)
        axes[1].set_xlim(0, min(3.0, frame_times[-1]))

        # Frame labels
        label_numeric = [1 if l == 'voiced' else 0 for l in labels]
        axes[2].plot(frame_times, label_numeric, drawstyle='steps-post', linewidth=2)
        axes[2].set_title('Detected Labels')
        axes[2].set_ylabel('Voiced (1) / Unvoiced (0)')
        axes[2].set_yticks([0, 1])
        axes[2].grid(True, alpha=0.3)
        axes[2].set_xlim(0, min(3.0, frame_times[-1]))

        # Boundary markers on signal
        axes[3].plot(t, signal, linewidth=0.5, alpha=0.5)
        for time, label in boundaries:
            if time < 3.0:  # Only show boundaries in visible range
                axes[3].axvline(x=time, color='red' if label == 'voiced' else 'blue',
                              linestyle='--', linewidth=1)
        axes[3].set_title('Detected Boundaries')
        axes[3].set_xlabel('Time (s)')
        axes[3].set_ylabel('Amplitude')
        axes[3].grid(True, alpha=0.3)
        axes[3].set_xlim(0, min(3.0, t[-1]))

        plt.tight_layout()
        plt.savefig(f"{PROJECT_PATH}/outputs/boundary_detection.pdf", dpi=300, bbox_inches='tight')
        plt.close()

        print(f" Boundary detection plot saved")
        print(f" Found {len(boundaries)} boundaries")
        print(f" Total frames: {len(labels)}")
        print(f" Voiced frames: {sum(1 for l in labels if l == 'voiced')}")
        print(f" Unvoiced frames: {sum(1 for l in labels if l == 'unvoiced')}")

        return boundaries

# Add this helper to voiced_unvoiced.py
def load_processed_signal(project_path):
    """Load signal saved by mfcc_manual.py"""
    signal_file = f"{project_path}/data/processed_signal.npy"
    if os.path.exists(signal_file):
        data = np.load(signal_file, allow_pickle=True).item()
        return data['signal'], data['sample_rate']
    return None, None


if __name__ == "__main__":
    print(" Detecting Voiced/Unvoiced Boundaries...")
    PROJECT_PATH = "/content/drive/MyDrive/q1_cepstral_pipeline"
    '''# Generate test signal with known voiced/unvoiced segments
    sample_rate = 16000
    duration = 3.0
    t = np.linspace(0, duration, int(sample_rate * duration))

    # Create segments: voiced-unvoiced-voiced
    signal = np.zeros_like(t)

    # 0-1s: Voiced (harmonic)
    signal[:sample_rate] = 0.5*np.sin(2*np.pi*150*t[:sample_rate]) + 0.2*np.sin(2*np.pi*300*t[:sample_rate])

    # 1-2s: Unvoiced (noise)
    signal[sample_rate:2*sample_rate] = 0.15*np.random.randn(sample_rate)

    # 2-3s: Voiced (different pitch)
    signal[2*sample_rate:] = 0.5*np.sin(2*np.pi*200*t[2*sample_rate:]) + 0.2*np.sin(2*np.pi*400*t[2*sample_rate:])

    # Add slight noise
    signal += 0.02 * np.random.randn(len(signal))'''
    import sys,os
    sys.path.insert(0, PROJECT_PATH)
    
    # Try to load processed signal first
    signal, sample_rate = load_processed_signal(PROJECT_PATH)
    
    if signal is None:
        # Fall back to synthetic
        print("⚠️  No processed signal found, generating synthetic...")
        # ... (synthetic generation code)
    else:
        print(f"✅ Using processed signal: {len(signal)/sample_rate:.2f}s @ {sample_rate}Hz")

    # Detect boundaries
    detector = VoicedUnvoicedDetector(sample_rate=sample_rate)
    boundaries, labels, scores, times = detector.detect_boundaries(signal)

    # Plot
    detector.plot_detection(signal, boundaries, labels, scores, times, sample_rate,PROJECT_PATH)

    # Print boundaries
    print("\n Detected Boundaries:")
    for time, label in boundaries:
        print(f"  {time:.2f}s → {label}")

    # Expected boundaries at ~1.0s and ~2.0s
    print("\n Expected: ~1.0s (voiced→unvoiced), ~2.0s (unvoiced→voiced)")
