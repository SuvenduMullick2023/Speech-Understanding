"""
Phonetic Mapping using Hugging Face Wav2Vec2 for Forced Alignment
Supports: Real audio files (.wav, .m4a, .flac, .mp3)
"""

import numpy as np
import torch
from transformers import Wav2Vec2ForCTC, Wav2Vec2Processor
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import json
import os
import sys

DEFAULT_PROJECT_PATH = "/content/drive/MyDrive/q1_cepstral_pipeline"

def load_audio_for_alignment(filepath, target_sr=16000, max_duration=30):
    """
    Load and prepare audio for Wav2Vec2 alignment
    
    Args:
        filepath: Path to audio file
        target_sr: Target sample rate (Wav2Vec2 expects 16kHz)
        max_duration: Max duration in seconds to avoid OOM
    
    Returns:
        audio: Normalized mono audio as numpy array
        sample_rate: Actual sample rate
    """
    try:
        import torchaudio
        waveform, sr = torchaudio.load(filepath)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        if sr != target_sr:
            waveform = torchaudio.functional.resample(waveform, sr, target_sr)
            sr = target_sr
        audio = waveform.numpy().flatten()
        audio = audio / (np.max(np.abs(audio)) + 1e-8)
        
        # Trim long files to avoid memory issues
        max_samples = int(max_duration * sr)
        if len(audio) > max_samples:
            print(f"  Trimming audio from {len(audio)/sr:.1f}s to {max_duration}s")
            audio = audio[:max_samples]
        
        return audio, sr
    except Exception as e:
        print(f" Error loading {filepath}: {e}")
        return None, None


class PhoneticAligner:
    """Use Wav2Vec2 for phonetic alignment and boundary comparison"""
    
    def __init__(self, model_name="facebook/wav2vec2-base-960h", device=None):
        """
        Args:
            model_name: HuggingFace model identifier
            device: 'cuda' or 'cpu' (auto-detected if None)
        """
        if device is None:
            device = 'cuda' if torch.cuda.is_available() else 'cpu'
        
        print(f" Loading {model_name} on {device}...")
        self.device = device
        self.processor = Wav2Vec2Processor.from_pretrained(model_name)
        self.model = Wav2Vec2ForCTC.from_pretrained(model_name).to(device)
        self.model.eval()
        print(f" Model loaded on {device}")
        
    def align_audio(self, audio, sample_rate=16000):
        """
        Get frame-level predictions from Wav2Vec2
        
        Returns:
            predictions: list of (time, token, confidence)
            transcription: decoded text string
        """
        # Ensure input is 16kHz mono
        if sample_rate != 16000:
            import torchaudio
            audio_tensor = torch.tensor(audio).unsqueeze(0)
            audio_tensor = torchaudio.functional.resample(audio_tensor, sample_rate, 16000)
            audio = audio_tensor.numpy().flatten()
            sample_rate = 16000
        
        # Preprocess for Wav2Vec2
        input_values = self.processor(audio, sampling_rate=sample_rate, 
                                     return_tensors="pt").input_values.to(self.device)
        
        # Forward pass
        with torch.no_grad():
            logits = self.model(input_values).logits
        
        # Get predictions
        predicted_ids = torch.argmax(logits, dim=-1)[0].cpu()
        transcription = self.processor.batch_decode(predicted_ids)[0]
        
        # Extract frame-level info (~50 fps for Wav2Vec2)
        frame_rate = 50
        frame_duration = 1.0 / frame_rate
        
        predictions = []
        for i, token_id in enumerate(predicted_ids):
            token = self.processor.tokenizer.decode([token_id]).strip()
            if token:  # Skip blank tokens
                confidence = torch.softmax(logits[0, i], dim=0)[token_id].cpu().item()
                time = i * frame_duration
                predictions.append({
                    'time': time,
                    'token': token,
                    'confidence': confidence
                })
        
        return predictions, transcription
    
    def compute_boundary_rmse(self, manual_boundaries, model_predictions, tolerance=0.05):
        """
        Compute RMSE between manual and model boundaries
        
        Args:
            manual_boundaries: list of (time, label) from voiced_unvoiced.py
            model_predictions: list of (time, token, confidence) from align_audio
            tolerance: seconds within which to match boundaries
        
        Returns:
            dict with RMSE and matching statistics
        """
        # Extract model boundary candidates (token transitions)
        model_boundaries = []
        for i in range(1, len(model_predictions)):
            if model_predictions[i]['token'] != model_predictions[i-1]['token']:
                model_boundaries.append(model_predictions[i]['time'])
        
        if len(model_boundaries) == 0:
            return {
                'rmse_seconds': float('inf'),
                'rmse_ms': float('inf'),
                'matched_count': 0,
                'error': 'No model boundaries detected'
            }
        
        # Match manual to model boundaries
        matched = []
        unmatched_manual = []
        model_times = model_boundaries.copy()
        
        for man_time, man_label in manual_boundaries:
            if len(model_times) == 0:
                unmatched_manual.append((man_time, man_label))
                continue
            closest_idx = np.argmin(np.abs(np.array(model_times) - man_time))
            model_time = model_times[closest_idx]
            error = abs(man_time - model_time)
            
            if error <= tolerance:
                matched.append((man_time, model_time, error))
                model_times.pop(closest_idx)
            else:
                unmatched_manual.append((man_time, man_label))
        
        # Calculate RMSE
        if len(matched) > 0:
            errors = [e for _, _, e in matched]
            rmse = np.sqrt(np.mean(np.array(errors)**2))
        else:
            rmse = float('inf')
        
        return {
            'rmse_seconds': rmse,
            'rmse_ms': rmse * 1000,
            'matched_count': len(matched),
            'total_manual': len(manual_boundaries),
            'total_model': len(model_boundaries),
            'unmatched_manual': len(unmatched_manual),
            'matched_pairs': matched
        }
    
    def plot_alignment_comparison(self, audio, sample_rate, manual_boundaries, 
                                 output_path, title="Alignment Comparison"):
        """Visualize manual vs model alignment"""
        predictions, transcription = self.align_audio(audio, sample_rate)
        results = self.compute_boundary_rmse(manual_boundaries, predictions)
        
        fig, axes = plt.subplots(3, 1, figsize=(14, 10), sharex=True)
        t = np.arange(len(audio)) / sample_rate
        
        # Original signal
        axes[0].plot(t, audio, linewidth=0.5)
        axes[0].set_title(f'Original Signal\nTranscription: "{transcription[:60]}{"..." if len(transcription)>60 else ""}"')
        axes[0].set_ylabel('Amplitude')
        axes[0].grid(True, alpha=0.3)
        axes[0].set_xlim(0, min(5.0, t[-1]))
        
        # Manual boundaries
        axes[1].plot(t, audio, linewidth=0.3, alpha=0.3)
        for time, label in manual_boundaries:
            if time < 5.0:
                axes[1].axvline(x=time, color='blue', linestyle='--', linewidth=2, 
                              label=f'Manual: {label}' if time == manual_boundaries[0][0] else "")
        axes[1].set_title('Manual Boundaries (Voiced/Unvoiced)')
        axes[1].set_ylabel('Amplitude')
        axes[1].legend(fontsize=8, loc='upper right')
        axes[1].grid(True, alpha=0.3)
        axes[1].set_xlim(0, min(5.0, t[-1]))
        
        # Model boundaries
        axes[2].plot(t, audio, linewidth=0.3, alpha=0.3)
        model_times = [p['time'] for p in predictions if p['token']]
        for mt in model_times[::3]:  # Plot every 3rd to avoid clutter
            if mt < 5.0:
                axes[2].axvline(x=mt, color='red', linestyle=':', linewidth=1)
        axes[2].set_title('Model Token Boundaries (Wav2Vec2)')
        axes[2].set_xlabel('Time (s)')
        axes[2].set_ylabel('Amplitude')
        axes[2].grid(True, alpha=0.3)
        axes[2].set_xlim(0, min(5.0, t[-1]))
        
        # RMSE annotation
        rmse_text = f"RMSE: {results['rmse_ms']:.1f} ms" if results['rmse_ms'] != float('inf') else "RMSE: N/A"
        axes[0].text(0.02, 0.95, rmse_text, 
                    transform=axes[0].transAxes, 
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5),
                    fontsize=10)
        
        plt.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
        plt.tight_layout()
        plt.savefig(output_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return results


def run_full_pipeline(audio_path, project_path=None, skip_model=False):
    """
    Run complete phonetic mapping pipeline
    
    Args:
        audio_path: Path to audio file
        project_path: Output directory
        skip_model: If True, skip Wav2Vec2 (for testing)
    
    Returns:
        results dict or None
    """
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    print(f" Running Phonetic Mapping: {os.path.basename(audio_path)}")
    
    # Load audio
    audio, sample_rate = load_audio_for_alignment(audio_path, target_sr=16000, max_duration=30)
    if audio is None:
        return None
    
    print(f" Loaded: {len(audio)/sample_rate:.2f}s @ {sample_rate} Hz")
    
    if skip_model:
        print("  Skipping Wav2Vec2 (skip_model=True)")
        return {'skipped': True, 'duration': len(audio)/sample_rate}
    
    # Detect manual boundaries first
    from voiced_unvoiced import VoicedUnvoicedDetector
    detector = VoicedUnvoicedDetector(sample_rate=sample_rate)
    manual_boundaries, labels, scores, times = detector.detect_boundaries(audio)
    print(f" Detected {len(manual_boundaries)} manual boundaries")
    
    # Align with Wav2Vec2
    try:
        aligner = PhoneticAligner()
        output_path = f"{project_path}/outputs/alignment_results.pdf"
        results = aligner.plot_alignment_comparison(
            audio, sample_rate, manual_boundaries, output_path,
            title=f"Alignment: {os.path.basename(audio_path)}"
        )
        
        # Save results
        with open(f"{project_path}/outputs/alignment_results.json", 'w') as f:
            json.dump(results, f, indent=2)
        
        print("\n" + "="*60)
        print(" PHONETIC MAPPING RESULTS")
        print("="*60)
        print(f"RMSE: {results['rmse_ms']:.2f} ms" if results['rmse_ms'] != float('inf') else "RMSE: Could not compute")
        print(f"Matched boundaries: {results['matched_count']}/{results['total_manual']}")
        print(f"Unmatched manual: {results['unmatched_manual']}")
        print(f"Output: {output_path}")
        print("="*60)
        
        return results
        
    except Exception as e:
        print(f" Error during alignment: {e}")
        print(" Tip: Wav2Vec2 requires ~2GB RAM and ~30s for first load")
        return {'error': str(e)}


def run_demo_synthetic(project_path=None):
    """Demo with synthetic signal (no model download)"""
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    print(" Phonetic Mapping Demo (Synthetic - No Model Download)")
    
    # Create simple test signal
    sample_rate = 16000
    duration = 2.0
    t = np.linspace(0, duration, int(sample_rate * duration))
    audio = np.zeros_like(t)
    audio[:sample_rate//2] = 0.5*np.sin(2*np.pi*150*t[:sample_rate//2])
    audio[sample_rate//2:sample_rate] = 0.1*np.random.randn(sample_rate//2)
    audio[sample_rate:] = 0.5*np.sin(2*np.pi*200*t[sample_rate:])
    
    print("  Using synthetic audio for demo")
    print(" For real results: python phonetic_mapping.py --input your_file.m4a")
    
    # Show what would happen
    print("\n Expected workflow with real audio:")
    print("  1. Load audio → Resample to 16kHz")
    print("  2. Detect voiced/unvoiced boundaries (cepstral method)")
    print("  3. Run Wav2Vec2 for token-level alignment")
    print("  4. Compute RMSE between manual and model boundaries")
    print("  5. Generate visualization PDF")
    
    return {'demo': True}


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Phonetic Mapping with Wav2Vec2')
    parser.add_argument('--input', '-i', type=str, default=None, help='Path to real audio file')
    parser.add_argument('--project-path', '-p', type=str, default=DEFAULT_PROJECT_PATH)
    parser.add_argument('--skip-model', action='store_true', help='Skip Wav2Vec2 download (demo mode)')
    parser.add_argument('--synthetic', '-s', action='store_true', help='Use synthetic demo')
    args = parser.parse_args()
    
    os.makedirs(f"{args.project_path}/outputs", exist_ok=True)
    
    if args.synthetic or (not args.input and not os.path.exists(args.input if args.input else "")):
        run_demo_synthetic(args.project_path)
    elif args.input and os.path.exists(args.input):
        run_full_pipeline(args.input, args.project_path, skip_model=args.skip_model)
    else:
        print("  No input file provided. Use --input path/to/audio.m4a")
        print(" Or use --synthetic for demo mode")
