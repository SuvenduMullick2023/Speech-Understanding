"""
Spectral Leakage and SNR Analysis for Different Window Functions
Supports: Synthetic tones AND real speech audio files
"""

import numpy as np
from scipy.signal import get_window
from scipy.fftpack import fft
import matplotlib.pyplot as plt
import os
import sys

DEFAULT_PROJECT_PATH = "/content/drive/MyDrive/q1_cepstral_pipeline"

def load_audio_for_analysis(filepath, target_sr=16000, max_duration=0.1):
    """
    Load and prepare audio for spectral analysis
    
    Args:
        filepath: Path to audio file
        target_sr: Target sample rate
        max_duration: Max duration in seconds for FFT analysis (default: 100ms)
    
    Returns:
        signal: Normalized audio segment for analysis
        sample_rate: Actual sample rate
    """
    try:
        import torchaudio
        waveform, sr = torchaudio.load(filepath)
        if waveform.shape[0] > 1:
            waveform = waveform.mean(dim=0, keepdim=True)
        if sr != target_sr:
            waveform = torchaudio.functional.resample(waveform, sr, target_sr)
            sr = target_sr
        signal = waveform.numpy().flatten()
        signal = signal / (np.max(np.abs(signal)) + 1e-8)
        
        # Take a short segment for spectral analysis (avoid long signals)
        max_samples = int(max_duration * sr)
        if len(signal) > max_samples:
            # Find a voiced segment (higher energy) for better analysis
            energy = np.convolve(signal**2, np.ones(int(0.01*sr))/int(0.01*sr), mode='valid')
            start_idx = np.argmax(energy) if len(energy) > 0 else 0
            signal = signal[start_idx:start_idx+max_samples]
        
        return signal, sr
    except Exception as e:
        print(f"  Error loading {filepath}: {e}")
        return None, None


def calculate_spectral_leakage(signal, sample_rate=16000, window_type='hamming'):
    """Measure spectral leakage using main-lobe to side-lobe ratio"""
    window = get_window(window_type, len(signal))
    windowed = signal * window
    N = len(windowed)
    freqs = np.fft.rfftfreq(N, 1/sample_rate)
    spectrum = np.abs(fft(windowed))[:N//2 + 1]
    spectrum_db = 20 * np.log10(spectrum + 1e-10)
    
    main_peak_idx = np.argmax(spectrum)
    main_peak_mag = spectrum_db[main_peak_idx]
    
    # -3dB main lobe width
    threshold = main_peak_mag - 3
    left_idx, right_idx = main_peak_idx, main_peak_idx
    while left_idx > 0 and spectrum_db[left_idx] > threshold:
        left_idx -= 1
    while right_idx < len(spectrum_db)-1 and spectrum_db[right_idx] > threshold:
        right_idx += 1
    main_lobe_width = freqs[right_idx] - freqs[left_idx]
    
    # Side-lobe level
    side_lobe_mask = np.ones(len(spectrum_db), dtype=bool)
    side_lobe_mask[left_idx:right_idx] = False
    side_lobe_level = np.mean(spectrum_db[side_lobe_mask])
    
    leakage_ratio = main_peak_mag - side_lobe_level
    
    return {
        'leakage_ratio': leakage_ratio,
        'main_lobe_width': main_lobe_width,
        'side_lobe_level': side_lobe_level
    }


def calculate_snr_proxy(signal, sample_rate=16000, window_type='hamming'):
    """Estimate SNR using spectral flatness"""
    window = get_window(window_type, len(signal))
    windowed = signal * window
    spectrum = np.abs(fft(windowed))[:len(windowed)//2 + 1]
    spectrum = np.where(spectrum == 0, 1e-10, spectrum)
    
    geom_mean = np.exp(np.mean(np.log(spectrum)))
    arith_mean = np.mean(spectrum)
    spectral_flatness = geom_mean / arith_mean
    snr_db = -10 * np.log10(spectral_flatness + 1e-10)
    
    return {'snr_db': snr_db, 'spectral_flatness': spectral_flatness}


def compare_windows(signal, sample_rate=16000):
    """Compare all three window functions"""
    windows = ['boxcar', 'hamming', 'hann']
    results = {}
    for w in windows:
        leakage = calculate_spectral_leakage(signal, sample_rate, w)
        snr = calculate_snr_proxy(signal, sample_rate, w)
        results[w] = {**leakage, **snr}
    return results


def plot_window_comparison(signal, sample_rate=16000, project_path=None, title="Window Comparison"):
    """Generate comparison plots and table"""
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    results = compare_windows(signal, sample_rate)
    display_names = {'boxcar': 'Rectangular', 'hamming': 'Hamming', 'hann': 'Hanning'}
    
    print("\n" + "="*70)
    print(" SPECTRAL LEAKAGE & SNR COMPARISON")
    print("="*70)
    print(f"{'Window':<15} {'Leakage Ratio':>15} {'Main Lobe (Hz)':>18} {'SNR (dB)':>12}")
    print("-"*70)
    for w, r in results.items():
        name = display_names.get(w, w)
        print(f"{name:<15} {r['leakage_ratio']:>15.2f} {r['main_lobe_width']:>18.2f} {r['snr_db']:>12.2f}")
    print("="*70)
    
    # Plot
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    N = 512
    t = np.arange(N)
    
    for idx, w_type in enumerate(['boxcar', 'hamming', 'hann']):
        ax = axes[idx//2, idx%2]
        window = get_window(w_type, N)
        ax.plot(t, window, linewidth=2)
        ax.set_title(f'{display_names[w_type]} Window')
        ax.set_xlabel('Sample')
        ax.set_ylabel('Amplitude')
        ax.grid(True, alpha=0.3)
    
    # Spectral response with 1000 Hz tone
    ax = axes[1, 1]
    freqs = np.fft.rfftfreq(512, 1/sample_rate)
    test_signal = np.sin(2*np.pi*1000*np.arange(512)/sample_rate)
    for w_type in ['boxcar', 'hamming', 'hann']:
        window = get_window(w_type, 512)
        spectrum = np.abs(fft(test_signal * window))[:257]
        spectrum_db = 20*np.log10(spectrum + 1e-10)
        ax.plot(freqs, spectrum_db, label=display_names[w_type], linewidth=1.5)
    ax.set_title('Spectral Response (1000 Hz Tone)')
    ax.set_xlabel('Frequency (Hz)')
    ax.set_ylabel('Magnitude (dB)')
    ax.legend()
    ax.grid(True, alpha=0.3)
    ax.set_xlim(0, 4000)
    
    plt.suptitle(title, fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(f"{project_path}/outputs/leakage_comparison.pdf", dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f"\n Comparison plot saved to {project_path}/outputs/leakage_comparison.pdf")
    
    # Save results
    import json
    results_display = {display_names.get(k, k): v for k, v in results.items()}
    with open(f"{project_path}/outputs/leakage_results.json", 'w') as f:
        json.dump(results_display, f, indent=2)
    
    return results


def run_demo_synthetic(project_path=None):
    """Run demo with synthetic 1000 Hz tone"""
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    print(" Analyzing Spectral Leakage & SNR (Synthetic Tone)...")
    sample_rate = 16000
    duration = 0.1
    t = np.linspace(0, duration, int(sample_rate * duration))
    signal = np.sin(2*np.pi*1000*t) + 0.1*np.random.randn(len(t))
    
    results = plot_window_comparison(signal, sample_rate, project_path, 
                                     title="Spectral Analysis: 1000 Hz Synthetic Tone")
    
    best_window = max(results.keys(), key=lambda w: results[w]['leakage_ratio'])
    display_names = {'boxcar': 'Rectangular', 'hamming': 'Hamming', 'hann': 'Hanning'}
    print(f"\n Recommendation: Use '{display_names[best_window]}' window for best leakage suppression")
    
    return results


def run_demo_real(filepath, project_path=None):
    """Run spectral analysis on real speech audio"""
    if project_path is None:
        project_path = DEFAULT_PROJECT_PATH
    
    print(f" Analyzing Spectral Leakage & SNR for: {os.path.basename(filepath)}")
    
    signal, sample_rate = load_audio_for_analysis(filepath, target_sr=16000, max_duration=0.1)
    if signal is None:
        print(" Failed to load audio for analysis")
        return None
    
    print(f" Analyzing {len(signal)/sample_rate*1000:.1f}ms segment @ {sample_rate} Hz")
    
    filename = os.path.basename(filepath)
    results = plot_window_comparison(signal, sample_rate, project_path,
                                     title=f"Spectral Analysis: {filename}")
    
    best_window = max(results.keys(), key=lambda w: results[w]['leakage_ratio'])
    display_names = {'boxcar': 'Rectangular', 'hamming': 'Hamming', 'hann': 'Hanning'}
    print(f"\n For this speech segment: '{display_names[best_window]}' window recommended")
    
    return results


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description='Spectral Leakage & SNR Analysis')
    parser.add_argument('--input', '-i', type=str, default=None, help='Path to real audio file')
    parser.add_argument('--project-path', '-p', type=str, default=DEFAULT_PROJECT_PATH)
    parser.add_argument('--synthetic', '-s', action='store_true', help='Use synthetic tone')
    args = parser.parse_args()
    
    os.makedirs(f"{args.project_path}/outputs", exist_ok=True)
    
    if args.input and os.path.exists(args.input):
        run_demo_real(args.input, args.project_path)
    else:
        print("  No valid input file, using synthetic 1000 Hz tone")
        run_demo_synthetic(args.project_path)
