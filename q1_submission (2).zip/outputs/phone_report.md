# Phone-Level Alignment Report
**Audio Duration**: 29.98s
**Total Phones Detected**: 224
**Manual Boundaries**: 279

## Detected Phone Sequence
| Time (s) | Phone | Duration (ms) | Confidence |
|----------|-------|---------------|------------|
| 0.980 | `ɑ` | 120.0 | 0.779 |
| 1.100 | `l` | 80.0 | nan |
| 1.180 | `ɔ` | 240.0 | nan |
| 1.420 | `n` | 80.0 | nan |
| 1.500 | `ɛ` | 140.0 | nan |
| 1.640 | `t` | 140.0 | nan |
| 1.780 | `ɔ` | 200.0 | nan |
| 1.980 | `t` | 160.0 | nan |
| 2.140 | `ɛ` | 180.0 | nan |
| 2.320 | `t` | 60.0 | nan |
| 2.380 | `ɪ` | 260.0 | nan |
| 2.640 | `s` | 220.0 | nan |
| 2.860 | `ʊ` | 80.0 | nan |
| 2.940 | `p` | 80.0 | nan |
| 3.020 | `ɛ` | 40.0 | nan |
| 3.060 | `n` | 120.0 | nan |
| 3.180 | `d` | 100.0 | nan |
| 3.280 | `ɔ` | 1440.0 | nan |
| 4.720 | `ɑ` | 60.0 | 0.779 |
| 4.780 | `h` | 340.0 | nan |

*... and 204 more phones*

## Boundary Alignment Results
- **RMSE**: 57.21 ms
- **Matched Boundaries**: 141/279
- **Tolerance**: 100 ms

### Matched Boundary Pairs
| Manual Time | Manual Label | Phone Time | Phone | Error (ms) |
|-------------|--------------|------------|-------|------------|
| 0.910s | voiced | 0.980s | phone:ɑ | 70.0 |
| 1.600s | unvoiced | 1.640s | phone:t | 40.0 |
| 1.860s | unvoiced | 1.780s | phone:ɔ | 80.0 |
| 2.040s | voiced | 1.980s | phone:t | 60.0 |
| 2.420s | unvoiced | 2.380s | phone:ɪ | 40.0 |
| 2.610s | unvoiced | 2.640s | phone:s | 30.0 |
| 2.810s | voiced | 2.860s | phone:ʊ | 50.0 |
| 2.900s | unvoiced | 2.940s | phone:p | 40.0 |
| 2.930s | voiced | 3.020s | phone:ɛ | 90.0 |
| 4.760s | unvoiced | 4.780s | phone:h | 20.0 |
