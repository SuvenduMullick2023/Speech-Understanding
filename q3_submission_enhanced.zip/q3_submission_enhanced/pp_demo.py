
from privacymodule import PrivacyObfuscator
import torchaudio
import os

def run_demo(input_path, output_path, target_gender=None):
    """
    Run privacy obfuscation on audio file
    """
    if not os.path.exists(input_path):
        print(f"❌ Input file not found: {input_path}")
        return False
    
    obfuscator = PrivacyObfuscator()
    obfuscator.save_example(input_path, output_path, target_gender)
    
    print(f"✅ Privacy transformation complete!")
    print(f"📁 Output: {output_path}")
    return True

if __name__ == "__main__":
    # Demo with example files
    run_demo(
        "/content/drive/MyDrive/q3_ethical_audio/examples/original_demo.wav",
        "/content/drive/MyDrive/q3_ethical_audio/examples/obfuscated_demo.wav",
        target_gender='female'
    )
