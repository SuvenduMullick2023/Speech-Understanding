
import torch
import torchaudio
import numpy as np
import matplotlib.pyplot as plt
import librosa
import librosa.display
import os

def visualize_audio_comparison(original_path, modified_path, save_path):
    """
    Create spectrogram comparison for audit report
    """
    print(" Creating audio visualization...")
    
    # Load audio
    wav1, sr1 = torchaudio.load(original_path)
    wav2, sr2 = torchaudio.load(modified_path)
    
    # Convert to numpy
    y1 = wav1.numpy().flatten()
    y2 = wav2.numpy().flatten()
    
    # Compute spectrograms
    S1 = np.abs(librosa.stft(y1, n_fft=512, hop_length=128))
    S2 = np.abs(librosa.stft(y2, n_fft=512, hop_length=128))
    
    # Create figure
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Plot 1: Waveforms
    axes[0, 0].plot(y1[:2000], label='Original', alpha=0.7, linewidth=1)
    axes[0, 0].plot(y2[:2000], label='Modified', alpha=0.7, linewidth=1)
    axes[0, 0].set_title('Waveform Comparison (first 2000 samples)', fontsize=12, fontweight='bold')
    axes[0, 0].set_xlabel('Samples')
    axes[0, 0].set_ylabel('Amplitude')
    axes[0, 0].legend()
    axes[0, 0].grid(True, alpha=0.3)
    
    # Plot 2: Original Spectrogram
    img1 = librosa.display.specshow(
        librosa.amplitude_to_db(S1, ref=np.max), 
        sr=sr1, x_axis='time', y_axis='hz', ax=axes[0, 1]
    )
    axes[0, 1].set_title('Original Spectrogram', fontsize=12, fontweight='bold')
    axes[0, 1].set_xlabel('Time')
    axes[0, 1].set_ylabel('Frequency (Hz)')
    plt.colorbar(img1, ax=axes[0, 1], format='%+2.0f dB')
    
    # Plot 3: Modified Spectrogram
    img2 = librosa.display.specshow(
        librosa.amplitude_to_db(S2, ref=np.max), 
        sr=sr2, x_axis='time', y_axis='hz', ax=axes[1, 0]
    )
    axes[1, 0].set_title('Modified Spectrogram', fontsize=12, fontweight='bold')
    axes[1, 0].set_xlabel('Time')
    axes[1, 0].set_ylabel('Frequency (Hz)')
    plt.colorbar(img2, ax=axes[1, 0], format='%+2.0f dB')
    
    # Plot 4: Spectral Difference
    diff = np.abs(S1 - S2)
    img3 = librosa.display.specshow(
        librosa.amplitude_to_db(diff, ref=np.max), 
        sr=sr1, x_axis='time', y_axis='hz', ax=axes[1, 1]
    )
    axes[1, 1].set_title('Spectral Difference', fontsize=12, fontweight='bold')
    axes[1, 1].set_xlabel('Time')
    axes[1, 1].set_ylabel('Frequency (Hz)')
    plt.colorbar(img3, ax=axes[1, 1], format='%+2.0f dB')
    
    plt.tight_layout()
    
    plot_path = f"{save_path}/audio_comparison.pdf"
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    print(f" Audio visualization saved: {plot_path}")
    return plot_path

if __name__ == "__main__":
    # Test with example files
    original = "/content/drive/MyDrive/q3_ethical_audio/examples/original_0.wav"
    modified = "/content/drive/MyDrive/q3_ethical_audio/examples/obfuscated_0.wav"
    
    if os.path.exists(original) and os.path.exists(modified):
        visualize_audio_comparison(original, modified, "/content/drive/MyDrive/q3_ethical_audio")
    else:
        print("  Audio files not found. Run privacymodule.py first.")
