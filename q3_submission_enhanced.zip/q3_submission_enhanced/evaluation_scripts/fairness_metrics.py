
import numpy as np
from sklearn.metrics import accuracy_score, f1_score

def compute_fairness_metrics(predictions, labels, demographics, task='classification'):
    """
    Compute multiple fairness metrics across demographic groups
    
    Args:
        predictions: Model predictions (numpy array)
        labels: True labels (numpy array)
        demographics: Dict of {group_name: boolean_mask}
        task: 'classification' or 'regression'
    
    Returns:
        Dict with fairness metrics
    """
    results = {}
    
    for group, mask in demographics.items():
        group_preds = predictions[mask]
        group_labels = labels[mask]
        
        if len(group_labels) == 0:
            continue
        
        results[group] = {
            'accuracy': accuracy_score(group_labels, group_preds) if task == 'classification' else None,
            'f1': f1_score(group_labels, group_preds, average='weighted') if task == 'classification' else None,
            'samples': len(group_labels)
        }
    
    # Demographic Parity Difference
    if results:
        accuracies = [r['accuracy'] for r in results.values() if r['accuracy'] is not None]
        if len(accuracies) >= 2:
            dpd = max(accuracies) - min(accuracies)
        else:
            dpd = 0
    else:
        dpd = 0
    
    # Equalized Odds Difference (binary classification)
    eod_avg = None
    if task == 'classification' and len(np.unique(labels)) == 2:
        eod = []
        for label in np.unique(labels):
            tprs = []
            for group, mask in demographics.items():
                group_mask = mask & (labels == label)
                if group_mask.sum() > 0:
                    tpr = (predictions[group_mask] == label).mean()
                    tprs.append(tpr)
            if len(tprs) >= 2:
                eod.append(max(tprs) - min(tprs))
        eod_avg = np.mean(eod) if eod else 0
    
    return {
        'group_metrics': results,
        'demographic_parity_difference': dpd,
        'equalized_odds_difference': eod_avg,
        'fair': dpd < 0.1 and (eod_avg is None or eod_avg < 0.1)
    }

# Demo usage
if __name__ == "__main__":
    # Example test
    np.random.seed(42)
    n = 200
    predictions = np.random.randint(0, 2, n)
    labels = np.random.randint(0, 2, n)
    
    demographics = {
        'male': np.random.rand(n) > 0.5,
        'female': np.random.rand(n) <= 0.5
    }
    
    results = compute_fairness_metrics(predictions, labels, demographics)
    
    print("\n" + "="*60)
    print(" FAIRNESS METRICS RESULTS")
    print("="*60)
    print(f"Demographic Parity Difference: {results['demographic_parity_difference']:.4f}")
    print(f"Equalized Odds Difference: {results['equalized_odds_difference']}")
    print(f"Model is Fair: {results['fair']}")
    print("="*60)
    
    for group, metrics in results['group_metrics'].items():
        print(f"\n{group}:")
        print(f"  Samples: {metrics['samples']}")
        print(f"  Accuracy: {metrics['accuracy']:.3f}" if metrics['accuracy'] else "  Accuracy: N/A")
