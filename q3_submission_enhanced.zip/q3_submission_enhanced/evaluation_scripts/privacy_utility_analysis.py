
import torch
import torchaudio
import torchaudio.functional as F
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import os

def calculate_quality_proxy(original, modified):
    """Calculate audio quality proxy metrics"""
    # Spectral similarity
    spec1 = torch.abs(torch.stft(original, 512, 128, return_complex=True))
    spec2 = torch.abs(torch.stft(modified, 512, 128, return_complex=True))
    
    spectral_dist = torch.mean(torch.abs(spec1 - spec2)).item()
    correlation = torch.nn.functional.cosine_similarity(
        spec1.flatten().unsqueeze(0),
        spec2.flatten().unsqueeze(0)
    ).item()
    
    # Map to standard scales
    pesq_proxy = max(1.0, min(5.0, 5.0 - spectral_dist * 10))
    stoi_proxy = (correlation + 1) / 2
    
    return {
        'pesq': pesq_proxy,
        'stoi': stoi_proxy,
        'spectral_distance': spectral_dist
    }

def analyze_privacy_utility_tradeoff(save_path, n_samples=5):
    """
    Systematically evaluate different pitch shift levels
    """
    print(" Analyzing Privacy-Utility Trade-off...")
    
    from datasets import load_from_disk
    dataset = load_from_disk("/content/drive/MyDrive/q3_ethical_audio/librispeech_data")
    
    results = []
    
    # Load first sample for testing
    sample = dataset[0]
    audio = torch.tensor(sample['audio']['array']).unsqueeze(0)
    sr = sample['audio']['sampling_rate']
    
    if sr != 16000:
        audio = torchaudio.functional.resample(audio, sr, 16000)
    
    # Test different shift levels
    shifts = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
    
    for shift in shifts:
        for direction in [-1, 1]:
            modified = F.pitch_shift(audio, 16000, direction * shift)
            
            # Quality metrics
            quality = calculate_quality_proxy(audio, modified)
            
            # Privacy score (higher shift = more privacy)
            privacy_score = min(1.0, shift / 4.0)
            
            results.append({
                'shift_semitones': shift,
                'direction': 'up' if direction > 0 else 'down',
                'pesq': quality['pesq'],
                'stoi': quality['stoi'],
                'spectral_distance': quality['spectral_distance'],
                'privacy_score': privacy_score,
                'utility_score': quality['stoi']
            })
    
    df = pd.DataFrame(results)
    
    # Find optimal configuration
    df['combined_score'] = 0.5 * df['privacy_score'] + 0.5 * df['utility_score']
    best_config = df.loc[df['combined_score'].idxmax()]
    
    # Plot trade-off curve
    plt.figure(figsize=(10, 6))
    
    for direction in ['up', 'down']:
        subset = df[df['direction'] == direction]
        plt.plot(subset['shift_semitones'], subset['utility_score'], 
                label=f'{direction.capitalize()} Shift', marker='o', linewidth=2)
    
    plt.axhline(y=0.7, linestyle='--', color='green', linewidth=2, label='STOI Threshold (0.7)')
    plt.axvline(x=2.0, linestyle='--', color='red', linewidth=2, label='Recommended Max Shift')
    plt.xlabel('Pitch Shift (semitones)', fontsize=12)
    plt.ylabel('Utility Score (STOI Proxy)', fontsize=12)
    plt.title('Privacy-Utility Trade-off Analysis', fontsize=14, fontweight='bold')
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    
    plot_path = f"{save_path}/privacy_utility_curve.pdf"
    plt.savefig(plot_path, dpi=300, bbox_inches='tight')
    plt.close()
    
    # Save results
    df.to_csv(f"{save_path}/privacy_utility_results.csv", index=False)
    
    print("\n" + "="*60)
    print(" RECOMMENDED CONFIGURATION")
    print("="*60)
    print(f"Shift: {best_config['shift_semitones']} semitones ({best_config['direction']})")
    print(f"Expected STOI: {best_config['utility_score']:.3f}")
    print(f"Expected Privacy: {best_config['privacy_score']:.3f}")
    print(f"Combined Score: {best_config['combined_score']:.3f}")
    print("="*60)
    print(f" Plot saved: {plot_path}")
    print(f" Data saved: {save_path}/privacy_utility_results.csv")
    
    return df, best_config

if __name__ == "__main__":
    analyze_privacy_utility_tradeoff("/content/drive/MyDrive/q3_ethical_audio")
