
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import json
from datasets import load_from_disk

class GradientReversal(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, alpha=1.0):
        ctx.alpha = alpha
        return x.view_as(x)
    
    @staticmethod
    def backward(ctx, grad_output):
        return grad_output.neg() * ctx.alpha, None

def grad_reverse(x, alpha=1.0):
    return GradientReversal.apply(x, alpha)

class FairSpeechModel(nn.Module):
    """
    Speech Model with Fairness Loss (Adversarial Gender Removal)
    """
    def __init__(self, input_dim=128, hidden_dim=256):
        super().__init__()
        self.feature_extractor = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU()
        )
        self.gender_head = nn.Linear(hidden_dim, 2)  # male/female
        
    def forward(self, features, gender_labels=None, alpha=1.0):
        hidden = self.feature_extractor(features)
        
        if gender_labels is not None:
            reversed_features = grad_reverse(hidden, alpha)
            gender_pred = self.gender_head(reversed_features)
            fairness_loss = nn.CrossEntropyLoss()(gender_pred, gender_labels)
        else:
            fairness_loss = 0
            
        return hidden, fairness_loss

def extract_audio_features(dataset, n_samples=200):
    """Extract MFCC features from audio"""
    import librosa
    
    features = []
    labels = []
    
    for i in range(min(n_samples, len(dataset))):
        sample = dataset[i]
        audio = sample['audio']['array']
        
        # Extract MFCC
        mfcc = librosa.feature.mfcc(y=audio, sr=16000, n_mfcc=128)
        mfcc_mean = mfcc.mean(axis=1)  # Pool over time
        
        features.append(mfcc_mean)
        
        # Use synthetic gender label (from audit)
        gender = sample.get('gender', np.random.choice(['male', 'female']))
        labels.append(0 if gender == 'male' else 1)
    
    return torch.tensor(features, dtype=torch.float32), torch.tensor(labels, dtype=torch.long)

def train(save_path, epochs=15):
    print(" Training Fairness Model with LibriSpeech features...")
    
    # Load dataset
    dataset = load_from_disk("/content/drive/MyDrive/q3_ethical_audio/librispeech_data")
    
    # Extract features
    features, labels = extract_audio_features(dataset, n_samples=200)
    
    print(f"   Features shape: {features.shape}")
    print(f"   Labels shape: {labels.shape}")
    
    # Initialize model
    model = FairSpeechModel(input_dim=128)
    optimizer = torch.optim.Adam(model.parameters(), lr=1e-3)
    
    history = {'loss': [], 'accuracy': []}
    
    print("\n📈 Training Progress:")
    for epoch in range(epochs):
        model.train()
        optimizer.zero_grad()
        
        _, loss = model(features, labels, alpha=1.0)
        loss.backward()
        optimizer.step()
        
        # Track accuracy (should decrease toward 0.5)
        with torch.no_grad():
            hidden, _ = model(features)
            pred = model.gender_head(hidden).argmax(dim=1)
            acc = (pred == labels).float().mean().item()
        
        history['loss'].append(loss.item())
        history['accuracy'].append(acc)
        print(f"  Epoch {epoch+1}/{epochs}: Loss={loss.item():.4f}, Acc={acc:.3f}")
    
    # Plot
    plt.figure(figsize=(12, 4))
    
    plt.subplot(1, 2, 1)
    plt.plot(history['loss'], color='#e74c3c', linewidth=2)
    plt.title('Fairness Loss Over Training')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.grid(True, alpha=0.3)
    
    plt.subplot(1, 2, 2)
    plt.plot(history['accuracy'], color='#3498db', linewidth=2, label='Gender Accuracy')
    plt.axhline(0.5, linestyle='--', color='gray', label='Random Chance')
    plt.title('Gender Prediction Accuracy (Should Decrease)')
    plt.xlabel('Epoch')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(f"{save_path}/training_curves.pdf", dpi=300, bbox_inches='tight')
    plt.close()
    
    # Save history
    with open(f"{save_path}/training_history.json", 'w') as f:
        json.dump(history, f, indent=2)
    
    print(f"\n Final Accuracy: {history['accuracy'][-1]:.3f} (Target: ~0.5)")
    print(f" Saved: {save_path}/training_curves.pdf")
    
    return history

if __name__ == "__main__":
    train("/content/drive/MyDrive/q3_ethical_audio")
