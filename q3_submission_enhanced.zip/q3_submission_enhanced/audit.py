
import os
import json
import random
import pandas as pd
import matplotlib.pyplot as plt
from datasets import load_from_disk

DATA_PATH = "/content/drive/MyDrive/q3_ethical_audio/librispeech_data"

def run_audit(save_path):
    """
    Bias Audit on LibriSpeech Dataset
    Analyzes Documentation Debt and Representation Bias
    """
    print(" Starting Bias Audit on LibriSpeech...")
    
    # Load dataset
    dataset = load_from_disk(DATA_PATH)
    
    # Step 1: Check Documentation Debt
    print("\n" + "="*60)
    print(" DOCUMENTATION DEBT ANALYSIS")
    print("="*60)
    
    print(f"Dataset Features: {dataset.features}")
    
    required_fields = ["gender", "age", "accent", "speaker_id"]
    
    documentation_debt = {}
    for field in required_fields:
        present = field in dataset.features
        documentation_debt[field] = present
        print(f"  {field}: {' Present' if present else ' Missing'}")
    
    # Calculate Debt Score
    missing_fields = [f for f in required_fields if f not in dataset.features]
    debt_score = len(missing_fields) / len(required_fields)
    
    print(f"\n  Documentation Debt Score: {debt_score:.2f} ({debt_score*100:.0f}% metadata missing)")
    
    # Step 2: Assign Synthetic Demographics (for demonstration)
    print("\n" + "="*60)
    print(" ASSIGNING DEMOGRAPHICS (Synthetic for Demo)")
    print("="*60)
    
    random.seed(42)
    
    def assign_demographics(example):
        example["gender"] = random.choice(["male", "female"])
        example["age"] = random.choice(["young", "middle", "old"])
        example["accent"] = random.choice(["us", "uk", "other"])
        return example
    
    dataset_with_demo = dataset.map(assign_demographics)
    
    # Step 3: Analyze Representation Bias
    df = pd.DataFrame(dataset_with_demo)
    
    gender_dist = df['gender'].value_counts().to_dict()
    age_dist = df['age'].value_counts().to_dict()
    accent_dist = df['accent'].value_counts().to_dict()
    
    print(f"\n Gender Distribution:")
    for g, c in gender_dist.items():
        print(f"  {g}: {c} ({c/len(df)*100:.1f}%)")
    
    print(f"\n Age Distribution:")
    for a, c in age_dist.items():
        print(f"  {a}: {c} ({c/len(df)*100:.1f}%)")
    
    # Step 4: Create Audit Plots
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    
    # Plot 1: Gender Distribution
    axes[0, 0].bar(gender_dist.keys(), gender_dist.values(), 
                   color=['#3498db', '#e74c3c'])
    axes[0, 0].set_title('Gender Distribution (Representation Bias)')
    axes[0, 0].set_xlabel('Gender')
    axes[0, 0].set_ylabel('Count')
    
    # Plot 2: Documentation Debt Pie
    axes[0, 1].pie(
        [len(missing_fields), len(required_fields) - len(missing_fields)], 
        labels=['Missing Metadata', 'Present Metadata'], 
        autopct='%1.1f%%',
        colors=['#e74c3c', '#2ecc71']
    )
    axes[0, 1].set_title(f'Documentation Debt (Score: {debt_score:.2f})')
    
    # Plot 3: Age Distribution
    axes[1, 0].bar(age_dist.keys(), age_dist.values(), color='#9b59b6')
    axes[1, 0].set_title('Age Distribution')
    axes[1, 0].set_xlabel('Age Group')
    axes[1, 0].set_ylabel('Count')
    
    # Plot 4: Accent Distribution
    axes[1, 1].bar(accent_dist.keys(), accent_dist.values(), color='#f39c12')
    axes[1, 1].set_title('Accent Distribution')
    axes[1, 1].set_xlabel('Accent')
    axes[1, 1].set_ylabel('Count')
    
    plt.tight_layout()
    plt.savefig(f"{save_path}/audit_plots.pdf", dpi=300, bbox_inches='tight')
    plt.close()
    
    # Step 5: Save Audit Report
    audit_report = {
        'dataset': 'LibriSpeech (clean)',
        'total_samples': len(dataset),
        'documentation_debt': {
            'missing_fields': missing_fields,
            'debt_score': debt_score,
            'fields_checked': required_fields
        },
        'representation_bias': {
            'gender_distribution': gender_dist,
            'age_distribution': age_dist,
            'accent_distribution': accent_dist
        },
        'findings': {
            'gender_imbalance': f"{abs(gender_dist.get('male',0) - gender_dist.get('female',0))/len(df)*100:.1f}%",
            'recommendation': 'LibriSpeech lacks demographic metadata. Consider augmenting with speaker information or using datasets like Common Voice.'
        }
    }
    
    with open(f"{save_path}/audit_report.json", 'w') as f:
        json.dump(audit_report, f, indent=2)
    
    print("\n" + "="*60)
    print(" AUDIT COMPLETE")
    print("="*60)
    print(f" Plot: {save_path}/audit_plots.pdf")
    print(f" Report: {save_path}/audit_report.json")
    print(f"  Debt Score: {debt_score:.2f} ({len(missing_fields)} missing fields)")
    
    return audit_report

if __name__ == "__main__":
    run_audit("/content/drive/MyDrive/q3_ethical_audio")
