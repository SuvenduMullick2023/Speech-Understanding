
import torch
import torchaudio
import torchaudio.functional as F
import numpy as np
import os
from datasets import load_from_disk

class PrivacyObfuscator(torch.nn.Module):
    """Original pitch-shifting obfuscator"""
    
    def __init__(self, sample_rate=16000, shift_steps=4.0):
        super().__init__()
        self.sample_rate = sample_rate
        self.shift_steps = shift_steps
        
    def forward(self, waveform, target_gender=None):
        if target_gender == 'female':
            steps = self.shift_steps
        elif target_gender == 'male':
            steps = -self.shift_steps
        else:
            steps = np.random.choice([-self.shift_steps, self.shift_steps])
        
        return F.pitch_shift(waveform, self.sample_rate, steps)

class AdaptivePrivacyObfuscator(torch.nn.Module):
    """
    Enhanced privacy module with adjustable privacy-utility balance
    """
    
    def __init__(self, sample_rate=16000, max_shift=4.0, min_shift=1.0):
        super().__init__()
        self.sample_rate = sample_rate
        self.max_shift = max_shift
        self.min_shift = min_shift
        
    def forward(self, waveform, privacy_level=0.5):
        """
        Args:
            privacy_level: 0.0 (no privacy) to 1.0 (max privacy)
        """
        shift = self.min_shift + privacy_level * (self.max_shift - self.min_shift)
        direction = np.random.choice([-1, 1])
        return F.pitch_shift(waveform, self.sample_rate, direction * shift)
    
    def find_optimal_shift(self, waveform, target_pesq=3.0, max_iterations=10):
        """Find maximum shift that maintains quality"""
        best_shift = 0
        best_score = 0
        
        for shift in np.linspace(0.5, 4.0, max_iterations):
            modified = F.pitch_shift(waveform, self.sample_rate, shift)
            
            # Simple quality proxy (spectral similarity)
            spec1 = torch.abs(torch.stft(waveform, 512, 128, return_complex=True))
            spec2 = torch.abs(torch.stft(modified, 512, 128, return_complex=True))
            similarity = torch.nn.functional.cosine_similarity(
                spec1.flatten().unsqueeze(0),
                spec2.flatten().unsqueeze(0)
            ).item()
            
            if similarity >= target_pesq/5.0 and shift > best_shift:
                best_shift = shift
                best_score = similarity
        
        return best_shift, best_score

def create_examples_from_dataset(save_path, n_examples=3, use_adaptive=False, privacy_level=0.5):
    """Create audio examples with optional adaptive obfuscation"""
    print(" Creating audio examples from LibriSpeech...")
    
    dataset = load_from_disk("/content/drive/MyDrive/q3_ethical_audio/librispeech_data")
    
    if use_adaptive:
        obfuscator = AdaptivePrivacyObfuscator(sample_rate=16000)
    else:
        obfuscator = PrivacyObfuscator(sample_rate=16000, shift_steps=4.0)
    
    os.makedirs(f"{save_path}/examples", exist_ok=True)
    
    for i in range(min(n_examples, len(dataset))):
        sample = dataset[i]
        audio = sample['audio']['array']
        sample_rate = sample['audio']['sampling_rate']
        
        audio_tensor = torch.tensor(audio).unsqueeze(0)
        
        if sample_rate != 16000:
            audio_tensor = torchaudio.functional.resample(audio_tensor, sample_rate, 16000)
        
        if use_adaptive:
            obfuscated = obfuscator(audio_tensor, privacy_level=privacy_level)
        else:
            obfuscated = obfuscator(audio_tensor, target_gender='female')
        
        torchaudio.save(f"{save_path}/examples/original_{i}.wav", audio_tensor, 16000)
        torchaudio.save(f"{save_path}/examples/obfuscated_{i}.wav", obfuscated, 16000)
        
        print(f"   Example {i+1} created")
    
    print(f"\n Saved {n_examples} audio pairs to {save_path}/examples/")
    return True

if __name__ == "__main__":
    # Run with adaptive obfuscation at 0.5 privacy level (balanced)
    create_examples_from_dataset(
        "/content/drive/MyDrive/q3_ethical_audio",
        n_examples=3,
        use_adaptive=True,
        privacy_level=0.5  # Balanced privacy-utility
    )
